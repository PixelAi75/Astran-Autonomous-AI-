package com.example.astranautonomousminecraftai;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.neoforged.neoforge.client.event.RegisterClientCommandsEvent;

public class AstranCommand {

    private static final Style PREFIX_STYLE = Style.EMPTY.withColor(ChatFormatting.GRAY);
    private static final Style INFO_STYLE = Style.EMPTY.withColor(ChatFormatting.WHITE);
    private static final Style SUCCESS_STYLE = Style.EMPTY.withColor(ChatFormatting.GREEN);
    private static final Style ERROR_STYLE = Style.EMPTY.withColor(ChatFormatting.RED);
    private static final Style HIGHLIGHT_STYLE = Style.EMPTY.withColor(ChatFormatting.YELLOW);

    public static void onRegisterClientCommands(RegisterClientCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();

        LiteralArgumentBuilder<CommandSourceStack> astran = LiteralArgumentBuilder
                .<CommandSourceStack>literal("astran")
                .executes(AstranCommand::executeRoot);

        astran.then(LiteralArgumentBuilder.<CommandSourceStack>literal("help")
                .executes(AstranCommand::executeHelp));

        astran.then(LiteralArgumentBuilder.<CommandSourceStack>literal("on")
                .executes(AstranCommand::executeOn));

        astran.then(LiteralArgumentBuilder.<CommandSourceStack>literal("off")
                .executes(AstranCommand::executeOff));

        astran.then(LiteralArgumentBuilder.<CommandSourceStack>literal("status")
                .executes(AstranCommand::executeStatus));

        astran.then(LiteralArgumentBuilder.<CommandSourceStack>literal("settings")
                .executes(AstranCommand::executeSettings));

        astran.then(LiteralArgumentBuilder.<CommandSourceStack>literal("test")
                .executes(AstranCommand::executeTest));

        astran.then(LiteralArgumentBuilder.<CommandSourceStack>literal("clear")
                .executes(AstranCommand::executeClear));

        astran.then(LiteralArgumentBuilder.<CommandSourceStack>literal("tips")
                .then(LiteralArgumentBuilder.<CommandSourceStack>literal("on")
                        .executes(ctx -> executeTips(ctx, true)))
                .then(LiteralArgumentBuilder.<CommandSourceStack>literal("off")
                        .executes(ctx -> executeTips(ctx, false))));

        astran.then(LiteralArgumentBuilder.<CommandSourceStack>literal("resetwelcome")
                .executes(AstranCommand::executeResetWelcome));

        dispatcher.register(astran);
    }

    private static int executeRoot(CommandContext<CommandSourceStack> ctx) {
        sendPrefix("astran.command.root.title");
        sendPlain("astran.command.root.help");
        sendPlain("astran.command.root.on");
        sendPlain("astran.command.root.off");
        sendPlain("astran.command.root.status");
        sendPlain("astran.command.root.settings");
        sendPlain("astran.command.root.test");
        sendPlain("astran.command.root.clear");
        sendPlain("astran.command.root.tips");
        return 1;
    }

    private static int executeHelp(CommandContext<CommandSourceStack> ctx) {
        sendPrefix("astran.command.help.title");
        sendCommandHelp("/astran on", "astran.command.help.on");
        sendCommandHelp("/astran off", "astran.command.help.off");
        sendCommandHelp("/astran status", "astran.command.help.status");
        sendCommandHelp("/astran settings", "astran.command.help.settings");
        sendCommandHelp("/astran test", "astran.command.help.test");
        sendCommandHelp("/astran clear", "astran.command.help.clear");
        sendCommandHelp("/astran tips on|off", "astran.command.help.tips");
        sendCommandHelp("/astran resetwelcome", "astran.command.help.resetwelcome");
        sendCommandHelp("/astran help", "astran.command.help.help");
        return 1;
    }

    private static int executeOn(CommandContext<CommandSourceStack> ctx) {
        if (AstranConfig.AI_ENABLED.get()) {
            sendPrefix("astran.on.already");
        } else {
            AstranConfig.AI_ENABLED.set(true);
            sendPrefix("astran.on.success");
        }
        return 1;
    }

    private static int executeOff(CommandContext<CommandSourceStack> ctx) {
        if (!AstranConfig.AI_ENABLED.get()) {
            sendPrefix("astran.off.already");
        } else {
            AstranConfig.AI_ENABLED.set(false);
            sendPrefix("astran.off.success");
        }
        return 1;
    }

    private static int executeStatus(CommandContext<CommandSourceStack> ctx) {
        sendPrefix("astran.status.title");

        boolean aiEnabled = AstranConfig.AI_ENABLED.get();
        boolean tipsEnabled = AstranConfig.TIPS_ENABLED.get();
        boolean hasKey = AstranConfig.API_KEY.get() != null && !AstranConfig.API_KEY.get().isBlank();

        sendStatusLine("astran.status.ai", aiEnabled ? "astran.status.enabled" : "astran.status.disabled", aiEnabled);
        sendStatusLinePlain("astran.status.provider", AstranConfig.PROVIDER.get());
        sendStatusLinePlain("astran.status.model", AstranConfig.MODEL.get());
        sendStatusLine("astran.status.tips", tipsEnabled ? "astran.status.enabled" : "astran.status.disabled", tipsEnabled);
        sendStatusLinePlain("astran.status.memory", String.valueOf(AstranMemory.getMessageCount()));
        sendStatusLine("astran.status.api", hasKey ? "astran.status.configured" : "astran.status.not_configured", hasKey);
        return 1;
    }

    private static int executeSettings(CommandContext<CommandSourceStack> ctx) {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> mc.setScreen(new AstranSettingsScreen(mc.screen)));
        return 1;
    }

    private static int executeTest(CommandContext<CommandSourceStack> ctx) {
        String key = AstranConfig.API_KEY.get();
        if (key == null || key.isBlank()) {
            sendPlain("astran.test.no_key");
            return 1;
        }

        sendPlain("astran.test.running");
        AstranApiClient.testConnectionAsync(key).thenAccept(success -> {
            Minecraft.getInstance().execute(() -> {
                if (success) {
                    sendPlain("astran.test.success");
                    AstranConfig.HAS_TESTED_API.set(true);
                } else {
                    sendPlain("astran.test.failure");
                }
            });
        });
        return 1;
    }

    private static int executeClear(CommandContext<CommandSourceStack> ctx) {
        AstranMemory.clear();
        sendPrefix("astran.clear.success");
        return 1;
    }

    private static int executeTips(CommandContext<CommandSourceStack> ctx, boolean enable) {
        boolean current = AstranConfig.TIPS_ENABLED.get();
        if (enable) {
            if (current) {
                sendPrefix("astran.tips.already_enabled");
            } else {
                AstranConfig.TIPS_ENABLED.set(true);
                sendPrefix("astran.tips.enabled");
            }
        } else {
            if (!current) {
                sendPrefix("astran.tips.already_disabled");
            } else {
                AstranConfig.TIPS_ENABLED.set(false);
                sendPrefix("astran.tips.disabled");
            }
        }
        return 1;
    }

    private static int executeResetWelcome(CommandContext<CommandSourceStack> ctx) {
        AstranWelcome.resetWelcome();
        sendPrefix("astran.resetwelcome.success");
        return 1;
    }

    // ---- Helper methods ----

    private static void sendPrefix(String key) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        MutableComponent msg = Component.translatable("astran.prefix.mod").copy();
        msg.append(" ");
        msg.append(Component.translatable(key));
        msg.setStyle(PREFIX_STYLE);
        mc.player.displayClientMessage(msg, false);
    }

    private static void sendPlain(String key) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        mc.player.displayClientMessage(Component.translatable(key).setStyle(INFO_STYLE), false);
    }

    private static void sendCommandHelp(String command, String descKey) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        MutableComponent msg = Component.literal(command).setStyle(HIGHLIGHT_STYLE).copy();
        msg.append(" - ");
        msg.append(Component.translatable(descKey).setStyle(INFO_STYLE));
        mc.player.displayClientMessage(msg, false);
    }

    private static void sendStatusLine(String labelKey, String valueKey, boolean valueIsGood) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        MutableComponent label = Component.translatable(labelKey).setStyle(INFO_STYLE).copy();
        label.append(": ");
        Style valueStyle = valueIsGood ? SUCCESS_STYLE : ERROR_STYLE;
        label.append(Component.translatable(valueKey).setStyle(valueStyle));

        mc.player.displayClientMessage(label, false);
    }

    private static void sendStatusLinePlain(String labelKey, String value) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        MutableComponent label = Component.translatable(labelKey).setStyle(INFO_STYLE).copy();
        label.append(": ");
        label.append(Component.literal(value).setStyle(HIGHLIGHT_STYLE));

        mc.player.displayClientMessage(label, false);
    }
}
