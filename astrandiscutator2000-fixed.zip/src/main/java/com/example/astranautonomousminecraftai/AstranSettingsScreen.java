package com.example.astranautonomousminecraftai;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class AstranSettingsScreen extends Screen {
    private final Screen parent;
    private EditBox apiKeyBox;
    private EditBox personalityBox;
    private EditBox systemPromptBox;
    private EditBox goalBox;
    private Button modelButton;
    private Button aiToggleButton;
    private Button tipsToggleButton;
    private Button languageButton;
    private Button saveButton;
    private Button testButton;
    private Button clearMemoryButton;

    private boolean aiEnabled;
    private boolean tipsEnabled;
    private boolean asciiOnly;
    private String currentLangCode;
    private String currentModelId;

    public AstranSettingsScreen(Screen parent) {
        super(Component.translatable("astran.settings.title"));
        this.parent = parent;
        this.aiEnabled = AstranConfig.AI_ENABLED.get();
        this.tipsEnabled = AstranConfig.TIPS_ENABLED.get();
        this.asciiOnly = AstranConfig.ASCII_ONLY.get();
        this.currentLangCode = AstranConfig.LANGUAGE.get();
        this.currentModelId = AstranConfig.MODEL.get();
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int startY = 20;
        int fieldWidth = 200;

        // API Key
        this.apiKeyBox = new EditBox(this.font, centerX - fieldWidth / 2, startY, fieldWidth, 20,
                Component.translatable("astran.settings.api_key"));
        String currentKey = AstranConfig.API_KEY.get();
        this.apiKeyBox.setValue(currentKey.isEmpty() ? "" : maskKey(currentKey));
        this.apiKeyBox.setMaxLength(128);
        this.apiKeyBox.setHint(Component.translatable("astran.settings.api_key_hint"));
        this.addRenderableWidget(this.apiKeyBox);

        // Model (cycle button)
        this.modelButton = Button.builder(
                        getModelLabel(),
                        btn -> {
                            AstranModels.Model next = AstranModels.getNext(currentModelId);
                            currentModelId = next.id;
                            btn.setMessage(getModelLabel());
                        })
                .pos(centerX - fieldWidth / 2, startY + 22)
                .size(fieldWidth, 20)
                .build();
        this.addRenderableWidget(this.modelButton);

        // Personality
        this.personalityBox = new EditBox(this.font, centerX - fieldWidth / 2, startY + 46, fieldWidth, 20,
                Component.translatable("astran.settings.personality"));
        this.personalityBox.setValue(AstranConfig.PERSONALITY.get());
        this.personalityBox.setMaxLength(64);
        this.addRenderableWidget(this.personalityBox);

        // Language
        this.languageButton = Button.builder(
                        getLanguageLabel(),
                        btn -> {
                            AstranLanguage.Lang next = AstranLanguage.getNext(currentLangCode);
                            currentLangCode = next.code;
                            btn.setMessage(getLanguageLabel());
                        })
                .pos(centerX - fieldWidth / 2, startY + 70)
                .size(fieldWidth, 20)
                .build();
        this.addRenderableWidget(this.languageButton);

        // System Prompt
        this.systemPromptBox = new EditBox(this.font, centerX - fieldWidth / 2, startY + 94, fieldWidth, 20,
                Component.translatable("astran.settings.system_prompt"));
        this.systemPromptBox.setValue(AstranConfig.SYSTEM_PROMPT.get());
        this.systemPromptBox.setMaxLength(256);
        this.systemPromptBox.setHint(Component.translatable("astran.settings.system_prompt_hint"));
        this.addRenderableWidget(this.systemPromptBox);

        // Goal
        this.goalBox = new EditBox(this.font, centerX - fieldWidth / 2, startY + 118, fieldWidth, 20,
                Component.translatable("astran.settings.goal"));
        this.goalBox.setValue(AstranConfig.GOAL.get());
        this.goalBox.setMaxLength(128);
        this.goalBox.setHint(Component.translatable("astran.settings.goal_hint"));
        this.addRenderableWidget(this.goalBox);

        // AI Toggle
        this.aiToggleButton = Button.builder(
                        getToggleText("astran.settings.ai", aiEnabled),
                        btn -> {
                            aiEnabled = !aiEnabled;
                            btn.setMessage(getToggleText("astran.settings.ai", aiEnabled));
                        })
                .pos(centerX - fieldWidth / 2, startY + 146)
                .size(fieldWidth, 20)
                .build();
        this.addRenderableWidget(this.aiToggleButton);

        // Tips Toggle
        this.tipsToggleButton = Button.builder(
                        getToggleText("astran.settings.tips", tipsEnabled),
                        btn -> {
                            tipsEnabled = !tipsEnabled;
                            btn.setMessage(getToggleText("astran.settings.tips", tipsEnabled));
                        })
                .pos(centerX - fieldWidth / 2, startY + 170)
                .size(fieldWidth, 20)
                .build();
        this.addRenderableWidget(this.tipsToggleButton);

        // ASCII Only Toggle
        Button asciiToggleButton = Button.builder(
                        getToggleText("astran.settings.ascii_only", asciiOnly),
                        btn -> {
                            asciiOnly = !asciiOnly;
                            btn.setMessage(getToggleText("astran.settings.ascii_only", asciiOnly));
                        })
                .pos(centerX - fieldWidth / 2, startY + 194)
                .size(fieldWidth, 20)
                .build();
        this.addRenderableWidget(asciiToggleButton);

        // Test Connection
        this.testButton = Button.builder(
                        Component.translatable("astran.settings.test"),
                        btn -> testConnection())
                .pos(centerX - fieldWidth / 2, startY + 198)
                .size(fieldWidth / 2 - 5, 20)
                .build();
        this.addRenderableWidget(this.testButton);

        // Clear Memory
        this.clearMemoryButton = Button.builder(
                        Component.translatable("astran.settings.clear_memory"),
                        btn -> clearMemory())
                .pos(centerX + 5, startY + 198)
                .size(fieldWidth / 2 - 5, 20)
                .build();
        this.addRenderableWidget(this.clearMemoryButton);

        // Save
        this.saveButton = Button.builder(
                        Component.translatable("astran.settings.save"),
                        btn -> saveAndClose())
                .pos(centerX - fieldWidth / 2, this.height - 25)
                .size(fieldWidth, 20)
                .build();
        this.addRenderableWidget(this.saveButton);
    }

    private Component getToggleText(String key, boolean enabled) {
        return Component.translatable(key)
                .append(": ")
                .append(Component.translatable(enabled ? "astran.settings.on" : "astran.settings.off"));
    }

    private Component getLanguageLabel() {
        AstranLanguage.Lang lang = AstranLanguage.getByCode(currentLangCode);
        return Component.translatable("astran.settings.language")
                .append(": ")
                .append(Component.literal(lang.displayName));
    }

    private Component getModelLabel() {
        AstranModels.Model model = AstranModels.getById(currentModelId);
        return Component.translatable("astran.settings.model")
                .append(": ")
                .append(Component.literal(model.displayName));
    }

    private String maskKey(String key) {
        if (key.length() <= 8) return "********";
        return key.substring(0, 4) + "****" + key.substring(key.length() - 4);
    }

    private void testConnection() {
        String key = AstranConfig.API_KEY.get();
        if (key == null || key.isBlank()) {
            if (Minecraft.getInstance().player != null) {
                Minecraft.getInstance().player.displayClientMessage(
                        Component.translatable("astran.test.no_key"), false);
            }
            return;
        }
        if (Minecraft.getInstance().player != null) {
            Minecraft.getInstance().player.displayClientMessage(
                    Component.translatable("astran.test.running"), false);
        }
        AstranApiClient.testConnectionAsync(key).thenAccept(success -> {
            Minecraft.getInstance().execute(() -> {
                if (Minecraft.getInstance().player != null) {
                    Component msg = success
                            ? Component.translatable("astran.test.success")
                            : Component.translatable("astran.test.failure");
                    Minecraft.getInstance().player.displayClientMessage(msg, false);
                }
                if (success) {
                    AstranConfig.HAS_TESTED_API.set(true);
                }
            });
        });
    }

    private void clearMemory() {
        AstranMemory.clear();
        if (Minecraft.getInstance().player != null) {
            Minecraft.getInstance().player.displayClientMessage(
                    Component.translatable("astran.clear.success"), false);
        }
    }

    private void saveAndClose() {
        String newKey = this.apiKeyBox.getValue();
        if (!newKey.contains("*")) {
            AstranConfig.API_KEY.set(newKey);
            AstranConfig.HAS_CONFIGURED_KEY.set(!newKey.isBlank());
        }
        AstranConfig.MODEL.set(this.currentModelId);
        AstranConfig.PERSONALITY.set(this.personalityBox.getValue());
        AstranConfig.LANGUAGE.set(this.currentLangCode);
        AstranConfig.SYSTEM_PROMPT.set(this.systemPromptBox.getValue());
        AstranConfig.GOAL.set(this.goalBox.getValue());
        AstranGoalManager.setGoal(this.goalBox.getValue());
        AstranConfig.AI_ENABLED.set(aiEnabled);
        AstranConfig.TIPS_ENABLED.set(tipsEnabled);
        AstranConfig.ASCII_ONLY.set(asciiOnly);

        if (Minecraft.getInstance().player != null) {
            Minecraft.getInstance().player.displayClientMessage(
                    Component.translatable("astran.settings.saved"), false);
        }
        this.minecraft.setScreen(this.parent);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics, mouseX, mouseY, partialTick);
        super.render(graphics, mouseX, mouseY, partialTick);
        graphics.drawCenteredString(this.font, this.title, this.width / 2, 4, 0xFFFFFF);

        int centerX = this.width / 2;
        graphics.drawString(this.font, Component.translatable("astran.settings.api_key_label"),
                centerX - 100, 8, 0xAAAAAA);
        graphics.drawString(this.font, Component.translatable("astran.settings.model_label"),
                centerX - 100, 30, 0xAAAAAA);
        graphics.drawString(this.font, Component.translatable("astran.settings.personality_label"),
                centerX - 100, 54, 0xAAAAAA);
        graphics.drawString(this.font, Component.translatable("astran.settings.language_label"),
                centerX - 100, 78, 0xAAAAAA);
        graphics.drawString(this.font, Component.translatable("astran.settings.system_prompt_label"),
                centerX - 100, 102, 0xAAAAAA);
        graphics.drawString(this.font, Component.translatable("astran.settings.goal_label"),
                centerX - 100, 126, 0xAAAAAA);
        graphics.drawString(this.font, Component.translatable("astran.settings.ascii_only_label"),
                centerX - 100, 150, 0xAAAAAA);
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(this.parent);
    }
}
