package com.example.astranautonomousminecraftai;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class AstranTaskExecutor {
    private static final Minecraft MC = Minecraft.getInstance();
    private static AstranTask currentTask = null;
    private static int tickCounter = 0;
    private static BlockPos currentTarget = null;
    private static int stuckTicks = 0;
    private static double lastX = 0, lastZ = 0;
    private static final int SEARCH_RADIUS = 16; // réduit de 32 à 16 pour perf
    private static final int SEARCH_MAX_BLOCKS = 5000; // limite max de blocs scannés

    public static boolean hasTask() {
        return currentTask != null && !currentTask.completed && !currentTask.failed;
    }

    public static AstranTask getCurrentTask() {
        return currentTask;
    }

    public static void startTask(AstranTask task) {
        if (MC.player == null || MC.level == null) return;
        // Annuler toute action simple en cours
        AstranAutonomousBrain.stopCurrentAction();
        currentTask = task;
        task.currentStep = AstranTask.Step.FIND;
        task.stepTicks = 0;
        stuckTicks = 0;
        lastX = MC.player.getX();
        lastZ = MC.player.getZ();
        AstranAutonomousMinecraftAi.LOGGER.info("[AstranTask] Started: {}", task.description);
    }

    public static void cancelTask() {
        if (currentTask != null) {
            AstranAutonomousMinecraftAi.LOGGER.info("[AstranTask] Cancelled: {}", currentTask.description);
        }
        stopMovement();
        currentTask = null;
        currentTarget = null;
    }

    public static void onTick() {
        if (currentTask == null || currentTask.completed || currentTask.failed) return;
        if (MC.player == null || MC.level == null) {
            cancelTask();
            return;
        }

        tickCounter++;
        currentTask.stepTicks++;

        // Anti-stuck: si le joueur ne bouge pas depuis 3 secondes (sauf pendant BREAK ou COLLECT)
        if (tickCounter % 60 == 0 && currentTask.currentStep != AstranTask.Step.BREAK
                && currentTask.currentStep != AstranTask.Step.COLLECT) {
            double dx = MC.player.getX() - lastX;
            double dz = MC.player.getZ() - lastZ;
            if (Math.sqrt(dx*dx + dz*dz) < 0.3) {
                stuckTicks++;
                if (stuckTicks > 3) {
                    AstranAutonomousMinecraftAi.LOGGER.warn("[AstranTask] Stuck! Cancelling.");
                    currentTask.failed = true;
                    currentTask.failReason = "stuck";
                    stopMovement();
                    return;
                }
                // Try jump to get unstuck
                setKey(MC.options.keyJump, true);
            } else {
                stuckTicks = 0;
                setKey(MC.options.keyJump, false);
            }
            lastX = MC.player.getX();
            lastZ = MC.player.getZ();
        }

        switch (currentTask.currentStep) {
            case FIND -> stepFind();
            case PATHFIND -> stepPathfind();
            case APPROACH -> stepApproach();
            case LOOK -> stepLook();
            case BREAK -> stepBreak();
            case WAIT_DROP -> stepWaitDrop();
            case COLLECT -> stepCollect();
            case DONE -> stepDone();
        }
    }

    private static void stepFind() {
        if (currentTask.hasTargetPos()) {
            currentTarget = currentTask.targetPos;
            currentTask.currentStep = AstranTask.Step.PATHFIND;
            return;
        }
        BlockPos playerPos = MC.player.blockPosition();
        BlockPos found = findNearestBlock(playerPos, currentTask.targetBlock, SEARCH_RADIUS);
        if (found != null) {
            currentTarget = found;
            currentTask.currentStep = AstranTask.Step.PATHFIND;
            AstranAutonomousMinecraftAi.LOGGER.info("[AstranTask] Found {} at {}", currentTask.targetBlock, found);
        } else {
            currentTask.failed = true;
            currentTask.failReason = "block_not_found";
            AstranAutonomousMinecraftAi.LOGGER.warn("[AstranTask] Block not found: {}", currentTask.targetBlock);
        }
    }

    private static void stepPathfind() {
        if (currentTarget == null) {
            currentTask.failed = true;
            return;
        }
        double dist = distanceHorizontal(currentTarget);
        if (dist < 4.5) {
            stopMovement();
            currentTask.currentStep = AstranTask.Step.LOOK;
            return;
        }
        walkToward(currentTarget);
    }

    private static void stepApproach() {
        if (currentTarget == null) {
            currentTask.currentStep = AstranTask.Step.LOOK;
            return;
        }
        double dist = distanceHorizontal(currentTarget);
        if (dist < 4.5) {
            stopMovement();
            currentTask.currentStep = AstranTask.Step.LOOK;
            return;
        }
        walkToward(currentTarget);
    }

    private static void stepLook() {
        if (currentTarget == null) {
            currentTask.failed = true;
            return;
        }
        lookAtBlock(currentTarget);
        var hit = MC.hitResult;
        if (hit instanceof net.minecraft.world.phys.BlockHitResult bh) {
            if (bh.getBlockPos().equals(currentTarget)) {
                currentTask.currentStep = AstranTask.Step.BREAK;
                currentTask.stepTicks = 0;
                return;
            }
        }
        if (currentTask.stepTicks > 40) {
            currentTask.currentStep = AstranTask.Step.BREAK;
            currentTask.stepTicks = 0;
        }
    }

    private static void stepBreak() {
        if (currentTarget == null) {
            currentTask.failed = true;
            return;
        }
        setKey(MC.options.keyAttack, true);

        if (MC.level.getBlockState(currentTarget).isAir()) {
            setKey(MC.options.keyAttack, false);
            currentTask.currentStep = AstranTask.Step.WAIT_DROP;
            currentTask.stepTicks = 0;
            AstranAutonomousMinecraftAi.LOGGER.info("[AstranTask] Block broken, waiting for drop...");
            return;
        }

        if (currentTask.stepTicks > 200) {
            setKey(MC.options.keyAttack, false);
            currentTask.failed = true;
            currentTask.failReason = "break_timeout";
        }
    }

    private static void stepWaitDrop() {
        if (currentTask.stepTicks > 10) {
            currentTask.currentStep = AstranTask.Step.COLLECT;
            currentTask.stepTicks = 0;
        }
    }

    private static void stepCollect() {
        if (currentTarget == null) {
            currentTask.currentStep = AstranTask.Step.DONE;
            return;
        }
        // Verifier si l'item a deja ete ramasse (dans l'inventaire)
        if (hasItemInInventory(currentTask.targetBlock)) {
            currentTask.itemsCollected++;
            if (currentTask.itemsCollected >= currentTask.quantity) {
                currentTask.currentStep = AstranTask.Step.DONE;
            } else {
                currentTask.currentStep = AstranTask.Step.FIND;
            }
            return;
        }
        Vec3 center = Vec3.atCenterOf(currentTarget);
        AABB box = new AABB(center.x()-2, center.y()-2, center.z()-2, center.x()+2, center.y()+2, center.z()+2);
        List<ItemEntity> items = MC.level.getEntitiesOfClass(ItemEntity.class, box);

        if (!items.isEmpty()) {
            ItemEntity nearest = items.get(0);
            double dist = MC.player.distanceTo(nearest);
            if (dist < 1.5) {
                currentTask.itemsCollected++;
                if (currentTask.itemsCollected >= currentTask.quantity) {
                    currentTask.currentStep = AstranTask.Step.DONE;
                } else {
                    currentTask.currentStep = AstranTask.Step.FIND;
                }
            } else {
                walkToward(nearest.blockPosition());
            }
        } else {
            currentTask.currentStep = AstranTask.Step.DONE;
        }

        if (currentTask.stepTicks > 200) {
            currentTask.currentStep = AstranTask.Step.DONE;
        }
    }

    private static boolean hasItemInInventory(String blockName) {
        if (MC.player == null || blockName == null || blockName.isBlank()) return false;
        String search = blockName.toLowerCase();
        for (int i = 0; i < MC.player.getInventory().getContainerSize(); i++) {
            var stack = MC.player.getInventory().getItem(i);
            if (stack.isEmpty()) continue;
            String id = stack.getItem().getDescriptionId();
            int dot = id.lastIndexOf('.');
            String name = dot > 0 ? id.substring(dot+1) : id;
            if (name.toLowerCase().contains(search)) return true;
        }
        return false;
    }

    private static void stepDone() {
        stopMovement();
        currentTask.completed = true;
        AstranAutonomousMinecraftAi.LOGGER.info("[AstranTask] Completed: {}", currentTask.description);
    }

    // ========== UTILITAIRES ==========

    private static BlockPos findNearestBlock(BlockPos from, String blockName, int radius) {
        if (blockName == null || blockName.isBlank()) return null;
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        int scanned = 0;
        String search = blockName.toLowerCase();
        for (int dx = -radius; dx <= radius && scanned < SEARCH_MAX_BLOCKS; dx++) {
            for (int dy = -radius/2; dy <= radius/2 && scanned < SEARCH_MAX_BLOCKS; dy++) {
                for (int dz = -radius; dz <= radius && scanned < SEARCH_MAX_BLOCKS; dz++) {
                    scanned++;
                    BlockPos pos = from.offset(dx, dy, dz);
                    var state = MC.level.getBlockState(pos);
                    if (state.isAir()) continue;
                    String id = state.getBlock().getDescriptionId();
                    int dot = id.lastIndexOf('.');
                    String name = dot > 0 ? id.substring(dot+1) : id;
                    if (name.equalsIgnoreCase(blockName) || name.toLowerCase().contains(search)) {
                        double d = from.distSqr(pos);
                        if (d < bestDist) {
                            bestDist = d;
                            best = pos;
                        }
                    }
                }
            }
        }
        return best;
    }

    private static void walkToward(BlockPos target) {
        if (MC.player == null) return;
        double dx = target.getX() + 0.5 - MC.player.getX();
        double dz = target.getZ() + 0.5 - MC.player.getZ();
        double dist = Math.sqrt(dx*dx + dz*dz);
        if (dist < 0.1) {
            stopMovement();
            return;
        }

        double nx = dx / dist;
        double nz = dz / dist;
        float yaw = MC.player.getYRot();
        double fy = -Math.sin(Math.toRadians(yaw));
        double fx = Math.cos(Math.toRadians(yaw));

        double dotF = nx * fx + nz * fy;
        double dotR = nx * (-fy) + nz * fx;

        setKey(MC.options.keyUp, dotF > 0.3);
        setKey(MC.options.keyDown, dotF < -0.3);
        setKey(MC.options.keyRight, dotR > 0.3);
        setKey(MC.options.keyLeft, dotR < -0.3);

        if (dotF > 0.5 && shouldJump()) {
            setKey(MC.options.keyJump, true);
        } else {
            setKey(MC.options.keyJump, false);
        }
    }

    private static boolean shouldJump() {
        if (MC.player == null) return false;
        BlockPos front = MC.player.blockPosition().relative(
            net.minecraft.core.Direction.fromYRot(MC.player.getYRot()));
        var state = MC.level.getBlockState(front);
        return !state.isAir() && state.getBlock() != Blocks.CAVE_AIR && state.getBlock() != Blocks.WATER;
    }

    private static void lookAtBlock(BlockPos pos) {
        if (MC.player == null) return;
        double x = pos.getX() + 0.5;
        double y = pos.getY() + 0.5;
        double z = pos.getZ() + 0.5;
        double dx = x - MC.player.getX();
        double dy = y - (MC.player.getY() + MC.player.getEyeHeight());
        double dz = z - MC.player.getZ();
        double distH = Math.sqrt(dx*dx + dz*dz);
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, distH));
        MC.player.setYRot(yaw);
        MC.player.setXRot(pitch);
    }

    private static double distanceHorizontal(BlockPos pos) {
        if (MC.player == null) return Double.MAX_VALUE;
        double dx = pos.getX() + 0.5 - MC.player.getX();
        double dz = pos.getZ() + 0.5 - MC.player.getZ();
        return Math.sqrt(dx*dx + dz*dz);
    }

    private static void setKey(net.minecraft.client.KeyMapping key, boolean down) {
        key.setDown(down);
    }

    static void stopMovement() {
        setKey(MC.options.keyUp, false);
        setKey(MC.options.keyDown, false);
        setKey(MC.options.keyLeft, false);
        setKey(MC.options.keyRight, false);
        setKey(MC.options.keyJump, false);
        setKey(MC.options.keyAttack, false);
        setKey(MC.options.keyUse, false);
        setKey(MC.options.keyShift, false);
        setKey(MC.options.keySprint, false);
    }
}
