package com.example.astranautonomousminecraftai;

import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.gui.ConfigurationScreen;
import net.neoforged.neoforge.client.gui.IConfigScreenFactory;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;

@Mod(value = AstranAutonomousMinecraftAi.MODID, dist = Dist.CLIENT)
public class AstranAutonomousMinecraftAiClient {

    private static final int TIP_CHECK_INTERVAL = 1200;
    private int tickCounter = 0;
    private boolean welcomeShownThisSession = false;

    public AstranAutonomousMinecraftAiClient(IEventBus modEventBus, ModContainer container) {
        container.registerExtensionPoint(IConfigScreenFactory.class, ConfigurationScreen::new);
        container.registerConfig(ModConfig.Type.CLIENT, AstranConfig.SPEC);

        modEventBus.addListener(this::onClientSetup);

        NeoForge.EVENT_BUS.register(this);
        NeoForge.EVENT_BUS.addListener(AstranCommand::onRegisterClientCommands);
        NeoForge.EVENT_BUS.addListener(AstranChatListener::onChatReceived);
        NeoForge.EVENT_BUS.addListener(AstranAutonomousBrain::onTick);
    }

    private void onClientSetup(FMLClientSetupEvent event) {
        // Init router APRES que la config soit chargee
        AstranModelRouter.init(AstranConfig.MODEL.get());
        AstranAutonomousMinecraftAi.LOGGER.info("[Astran Autonomous Minecraft AI] Client setup complete.");
    }

    @SubscribeEvent
    public void onEntityJoinLevel(EntityJoinLevelEvent event) {
        if (welcomeShownThisSession) return;
        if (event.getEntity() != Minecraft.getInstance().player) return;
        if (AstranConfig.HAS_SEEN_WELCOME.get()) return;

        welcomeShownThisSession = true;
        AstranWelcome.onClientReady();
    }

    @SubscribeEvent
    public void onClientTick(ClientTickEvent.Post event) {
        tickCounter++;
        if (tickCounter >= TIP_CHECK_INTERVAL) {
            tickCounter = 0;
            AstranTips.tryShowTip();
        }
    }
}
