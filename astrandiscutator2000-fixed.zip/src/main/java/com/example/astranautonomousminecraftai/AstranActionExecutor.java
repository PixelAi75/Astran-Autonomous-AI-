package com.example.astranautonomousminecraftai;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.Map;

public class AstranActionExecutor {

    private static final Minecraft MC = Minecraft.getInstance();
    private static AstranAction currentAction = AstranAction.NONE;

    public static void startAction(AstranAction action, Map<String, String> params) {
        if (MC.player == null || MC.level == null) return;

        currentAction = action;

        switch (action) {
            case MOVE_FORWARD -> setKey(MC.options.keyUp, true);
            case MOVE_BACKWARD -> setKey(MC.options.keyDown, true);
            case MOVE_LEFT -> setKey(MC.options.keyLeft, true);
            case MOVE_RIGHT -> setKey(MC.options.keyRight, true);
            case JUMP -> setKey(MC.options.keyJump, true);
            case SNEAK -> setKey(MC.options.keyShift, true);
            case SPRINT -> setKey(MC.options.keySprint, true);
            case STOP -> stopAll();
            case PLACE_BLOCK -> placeBlock();
            case BREAK_BLOCK -> breakBlock();
            case USE_ITEM -> useItem();
            case ATTACK -> attack();
            case DROP_ITEM -> dropItem();
            case SWAP_SLOT -> swapSlot(params.getOrDefault("slot", "0"));
            case LOOK_AT -> lookAt(params.getOrDefault("x", "0"), params.getOrDefault("y", "0"), params.getOrDefault("z", "0"));
            case SAY -> say(params.getOrDefault("message", ""));
            case SET_GOAL -> AstranGoalManager.setGoal(params.getOrDefault("goal", ""));
            default -> {}
        }
    }

    public static void stopAll() {
        setKey(MC.options.keyUp, false);
        setKey(MC.options.keyDown, false);
        setKey(MC.options.keyLeft, false);
        setKey(MC.options.keyRight, false);
        setKey(MC.options.keyJump, false);
        setKey(MC.options.keyShift, false);
        setKey(MC.options.keySprint, false);
        setKey(MC.options.keyAttack, false);
        setKey(MC.options.keyUse, false);
        currentAction = AstranAction.NONE;
    }

    private static void setKey(KeyMapping key, boolean down) {
        key.setDown(down);
    }

    private static void placeBlock() {
        var hit = MC.hitResult;
        if (hit instanceof BlockHitResult blockHit) {
            BlockPos pos = blockHit.getBlockPos().relative(blockHit.getDirection());
            Vec3 vec = Vec3.atCenterOf(pos);
            BlockHitResult placeHit = new BlockHitResult(vec, Direction.UP, pos, false);
            MC.gameMode.useItemOn(MC.player, InteractionHand.MAIN_HAND, placeHit);
        }
    }

    private static void breakBlock() {
        if (MC.gameMode != null && MC.hitResult instanceof BlockHitResult blockHit) {
            MC.gameMode.destroyBlock(blockHit.getBlockPos());
        }
    }

    private static void useItem() {
        if (MC.gameMode != null) {
            MC.gameMode.useItem(MC.player, InteractionHand.MAIN_HAND);
        }
    }

    private static void attack() {
        if (MC.gameMode != null && MC.crosshairPickEntity != null) {
            MC.gameMode.attack(MC.player, MC.crosshairPickEntity);
        }
    }

    private static void dropItem() {
        if (MC.player != null) {
            MC.player.drop(false);
        }
    }

    private static void swapSlot(String slotStr) {
        try {
            int slot = Integer.parseInt(slotStr);
            if (slot >= 0 && slot <= 8 && MC.player != null && MC.player.connection != null) {
                MC.player.connection.send(new ServerboundSetCarriedItemPacket(slot));
            }
        } catch (NumberFormatException ignored) {}
    }

    private static void lookAt(String xStr, String yStr, String zStr) {
        try {
            double x = Double.parseDouble(xStr);
            double y = Double.parseDouble(yStr);
            double z = Double.parseDouble(zStr);
            if (MC.player != null) {
                double dx = x - MC.player.getX();
                double dy = y - (MC.player.getY() + MC.player.getEyeHeight());
                double dz = z - MC.player.getZ();
                double dist = Math.sqrt(dx * dx + dz * dz);
                float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
                float pitch = (float) -Math.toDegrees(Math.atan2(dy, dist));
                MC.player.setYRot(yaw);
                MC.player.setXRot(pitch);
            }
        } catch (NumberFormatException ignored) {}
    }

    private static void say(String message) {
        if (MC.player != null && !message.isBlank()) {
            MC.player.connection.sendChat(message);
        }
    }
}
