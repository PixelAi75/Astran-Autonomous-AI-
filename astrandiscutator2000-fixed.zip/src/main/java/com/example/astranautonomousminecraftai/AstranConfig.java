package com.example.astranautonomousminecraftai;

import net.neoforged.neoforge.common.ModConfigSpec;

public class AstranConfig {
    private static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();

    public static final ModConfigSpec.BooleanValue AI_ENABLED = BUILDER
            .comment("Enable or disable Astran AI responses")
            .define("aiEnabled", true);

    public static final ModConfigSpec.BooleanValue TIPS_ENABLED = BUILDER
            .comment("Enable or disable Astran tips")
            .define("tipsEnabled", true);

    public static final ModConfigSpec.BooleanValue HAS_SEEN_WELCOME = BUILDER
            .comment("Whether the player has seen the welcome message")
            .define("hasSeenWelcomeMessage", false);

    public static final ModConfigSpec.ConfigValue<String> API_KEY = BUILDER
            .comment("Mistral API key (stored locally, never sent to server)")
            .define("apiKey", "");

    public static final ModConfigSpec.ConfigValue<String> MODEL = BUILDER
            .comment("AI model for ACTIONS (movement, mining, tasks): ministral-3b-2512 (ultra fast), ministral-8b-2512 (fast, recommended)")
            .define("model", "ministral-8b-2512");

    public static final ModConfigSpec.ConfigValue<String> CHAT_MODEL = BUILDER
            .comment("AI model for CHAT responses (conversation): devstral-2512 (smart), mistral-large-2512 (best quality)")
            .define("chatModel", "devstral-2512");

    public static final ModConfigSpec.ConfigValue<String> PROVIDER = BUILDER
            .comment("AI provider")
            .define("provider", "Mistral");

    public static final ModConfigSpec.ConfigValue<String> PERSONALITY = BUILDER
            .comment("Astran personality preset")
            .define("personality", "default");

    public static final ModConfigSpec.BooleanValue ASCII_ONLY = BUILDER
            .comment("Use only basic ASCII letters in AI responses (no emojis, accents, or special chars)")
            .define("asciiOnly", false);

    public static final ModConfigSpec.ConfigValue<String> LANGUAGE = BUILDER
            .comment("Language for AI responses: auto = same as chat, or en/fr/es/de/it/pt/ja/ko/zh/ru/ar/nl/pl/tr/sv/hi/th/vi/id")
            .define("language", "auto");

    public static final ModConfigSpec.ConfigValue<String> GOAL = BUILDER
            .comment("Current autonomous goal for the AI (e.g. 'Build a house', 'Explore the world')")
            .define("goal", "");

    public static final ModConfigSpec.ConfigValue<String> SYSTEM_PROMPT = BUILDER
            .comment("Base system prompt sent to the AI on every request")
            .define("systemPrompt",
                    "You are Astran, a witty Minecraft AI. Respond briefly in the same language as the player.");

    public static final ModConfigSpec.LongValue LAST_TIP_TIME = BUILDER
            .comment("Timestamp of the last shown tip (milliseconds)")
            .defineInRange("lastTipTimestamp", 0L, 0L, Long.MAX_VALUE);

    public static final ModConfigSpec.BooleanValue HAS_TESTED_API = BUILDER
            .comment("Whether the player has ever tested the API connection")
            .define("hasTestedApi", false);

    public static final ModConfigSpec.BooleanValue HAS_CONFIGURED_KEY = BUILDER
            .comment("Whether the player has ever configured an API key")
            .define("hasConfiguredKey", false);

    public static final ModConfigSpec.BooleanValue FALLBACK_ENABLED = BUILDER
            .comment("Enable automatic model fallback on rate limit")
            .define("fallbackEnabled", true);

    public static final ModConfigSpec.ConfigValue<String> FALLBACK_CHAIN = BUILDER
            .comment("Fallback model chain (comma-separated, in priority order)")
            .define("fallbackChain", "ministral-3b-2512,ministral-8b-2512,codestral-2508,devstral-2512");

    static final ModConfigSpec SPEC = BUILDER.build();
}
