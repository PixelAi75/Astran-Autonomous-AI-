package com.example.astranautonomousminecraftai;

import net.minecraft.client.Minecraft;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;

public class AstranAutonomousBrain {

    private static final int THINK_INTERVAL = 20; // 1 seconde à 20 TPS
    private static int tickCounter = 0;
    private static boolean isThinking = false;
    private static String lastAction = "none";
    private static int actionDuration = 0;
    private static String lastContext = "";
    private static int sameContextCount = 0;

    @SubscribeEvent
    public static void onTick(ClientTickEvent.Post event) {
        AstranTaskExecutor.onTick();

        // Ne pas agir si le joueur est mort ou spectateur
        if (Minecraft.getInstance().player == null || !Minecraft.getInstance().player.isAlive()
                || Minecraft.getInstance().player.isSpectator()) {
            if (AstranTaskExecutor.hasTask()) AstranTaskExecutor.cancelTask();
            if (actionDuration > 0) stopCurrentAction();
            tickCounter = 0;
            return;
        }

        if (!AstranConfig.AI_ENABLED.get()) {
            if (AstranTaskExecutor.hasTask()) {
                AstranTaskExecutor.cancelTask();
            }
            if (actionDuration > 0) {
                stopCurrentAction();
            }
            tickCounter = 0;
            return;
        }

        if (AstranTaskExecutor.hasTask()) {
            if (actionDuration > 0) {
                actionDuration--;
                if (actionDuration <= 0) {
                    stopCurrentAction();
                }
            }
            return;
        }

        tickCounter++;

        if (actionDuration > 0) {
            actionDuration--;
            if (actionDuration <= 0) {
                stopCurrentAction();
            }
        }

        if (tickCounter < THINK_INTERVAL) return;
        tickCounter = 0;

        String apiKey = AstranConfig.API_KEY.get();
        if (apiKey == null || apiKey.isBlank()) return;

        if (isThinking) return;

        // Fallback immediat si le modele actuel est bloque
        String model = AstranModelRouter.ensureCanSend();
        if (!AstranModelRouter.canSendRequest(model)) {
            return; // Tous les modeles sont bloques
        }

        String currentContext = AstranWorldContext.buildUltraCompactContext();
        if (currentContext.equals(lastContext)) {
            sameContextCount++;
            if (sameContextCount < 5 && actionDuration <= 0) {
                return;
            }
        } else {
            sameContextCount = 0;
            lastContext = currentContext;
        }

        think(currentContext, model);
    }

    private static void think(String worldContext, String model) {
        if (isThinking) return;

        String apiKey = AstranConfig.API_KEY.get();
        if (apiKey == null || apiKey.isBlank()) return;

        isThinking = true;

        String langCode = AstranConfig.LANGUAGE.get();
        String goal = AstranGoalManager.getGoal();

        String systemPrompt = buildTaskSystemPrompt(langCode);
        String prompt = "A:" + lastAction + "|D:" + actionDuration;

        AstranApiClient.sendAutonomousAiAsync(apiKey, model, systemPrompt, worldContext, goal, prompt)
                .thenAccept(response -> {
                    isThinking = false;
                    if (response == null || response.isBlank()) return;

                    AstranAiResponse aiResponse = AstranAiResponse.parse(response);

                    if (aiResponse.hasTask) {
                        AstranTask task = new AstranTask();
                        task.type = aiResponse.taskType;
                        task.targetBlock = aiResponse.taskBlock;
                        task.targetPos = AstranTask.parsePos(aiResponse.taskPos);
                        task.quantity = aiResponse.taskQty;
                        task.description = aiResponse.taskDesc;
                        if (!task.type.equals("none") && !task.type.isBlank()) {
                            Minecraft.getInstance().execute(() -> {
                                AstranTaskExecutor.startTask(task);
                            });
                            return;
                        }
                    }

                    if (aiResponse.action.equals(lastAction) && actionDuration > 0) {
                        return;
                    }

                    stopCurrentAction();

                    int duration = 20;
                    try {
                        String durStr = aiResponse.parameters.getOrDefault("duration", "20");
                        duration = Integer.parseInt(durStr);
                    } catch (NumberFormatException ignored) {}
                    if (duration < 1) duration = 1;
                    if (duration > 600) duration = 600;

                    AstranAction action = AstranAction.fromId(aiResponse.action);
                    if (action != AstranAction.NONE) {
                        lastAction = action.id;
                        actionDuration = duration;
                        Minecraft.getInstance().execute(() -> {
                            AstranActionExecutor.startAction(action, aiResponse.parameters);
                        });
                    }
                });
    }

    public static void stopCurrentAction() {
        if (!lastAction.equals("none")) {
            AstranActionExecutor.stopAll();
            lastAction = "none";
            actionDuration = 0;
        }
    }

    public static void overrideAction(AstranAction action, java.util.Map<String, String> params, int duration) {
        stopCurrentAction();
        lastAction = action.id;
        actionDuration = duration;
        AstranActionExecutor.startAction(action, params);
    }

    private static String buildTaskSystemPrompt(String langCode) {
        StringBuilder sb = new StringBuilder();
        sb.append("MC agent. Actions: fwd,bwd,lft,rgt,jmp,snk,spr,stp,plc,brk,use,atk,drp,swp,lk,say,goal. ");
        sb.append("TASKS: mine(block,pos,qty), build(block,pos), explore(radius), collect(item,qty), attack(target). ");
        sb.append("JSON:{t:thought,r:response,a:action,p:{d:duration}} OR {t:thought,r:response,task:mine,block:dirt,pos:x,y,z,qty:1,desc:text}. ");
        if (!"auto".equalsIgnoreCase(langCode)) {
            sb.append("Lang:").append(langCode).append(".");
        }
        return sb.toString();
    }
}
