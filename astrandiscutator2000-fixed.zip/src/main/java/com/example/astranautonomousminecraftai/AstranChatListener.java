package com.example.astranautonomousminecraftai;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.client.event.ClientChatReceivedEvent;

public class AstranChatListener {

    private static final long AI_COOLDOWN_MS = 2000L;
    private static final int CHAT_ACTION_DURATION = 60;
    private static long lastAiResponseTime = 0L;
    private static boolean isProcessing = false;
    private static long lastSentMessageTime = 0L;
    private static String lastSentMessage = "";
    private static String lastProcessedChat = "";

    @SubscribeEvent
    public static void onChatReceived(ClientChatReceivedEvent event) {
        if (!AstranConfig.AI_ENABLED.get()) return;

        String apiKey = AstranConfig.API_KEY.get();
        if (apiKey == null || apiKey.isBlank()) return;

        String messageText = event.getMessage().getString().trim();
        if (messageText.length() < 2) return;

        long now = System.currentTimeMillis();
        if (now - lastSentMessageTime < 8000L && messageText.equals(lastSentMessage)) {
            return;
        }
        if (messageText.startsWith("[Astran]")) return;
        if (messageText.startsWith("[Astran Autonomous Minecraft AI]")) return;
        if (messageText.equals(lastProcessedChat)) return;
        if (now - lastAiResponseTime < AI_COOLDOWN_MS) return;
        if (isProcessing) return;

        isProcessing = true;
        lastAiResponseTime = now;
        lastProcessedChat = messageText;

        // Modele CHAT separe (plus puissant pour conversation)
        String chatModel = AstranConfig.CHAT_MODEL.get();
        String basePrompt = AstranConfig.SYSTEM_PROMPT.get();
        String langCode = AstranConfig.LANGUAGE.get();
        String fullSystemPrompt = buildChatSystemPrompt(basePrompt, langCode);

        // Force le routeur a utiliser le modele chat
        String activeModel = AstranModelRouter.getCurrentModel();
        if (!chatModel.equals(activeModel)) {
            // On utilise directement le chatModel sans toucher au router d'actions
        }

        AstranApiClient.sendChatToAiAsync(apiKey, chatModel, fullSystemPrompt, messageText)
                .thenAccept(response -> {
                    isProcessing = false;
                    if (response == null || response.isBlank()) return;

                    // Filtre ASCII si active
                    String finalResponse = response;
                    if (AstranConfig.ASCII_ONLY.get()) {
                        finalResponse = toAscii(response);
                    }

                    // Parse pour extraire action + reponse
                    AstranAiResponse aiResponse = AstranAiResponse.parse(finalResponse);

                    // Action simple si presente
                    AstranAction action = AstranAction.fromId(aiResponse.action);
                    if (action != AstranAction.NONE) {
                        AstranAutonomousBrain.overrideAction(action, aiResponse.parameters, CHAT_ACTION_DURATION);
                    }

                    // Reponse chat
                    String chatReply = aiResponse.response;
                    if (chatReply == null || chatReply.isBlank()) {
                        // Si pas de champ "response", utiliser tout le texte
                        chatReply = finalResponse;
                    }
                    final String finalChatReply = sanitizeChatMessage(chatReply);
                    if (!finalChatReply.isEmpty() && !finalChatReply.equals(lastSentMessage)) {
                        Minecraft.getInstance().execute(() -> {
                            var player = Minecraft.getInstance().player;
                            if (player == null) return;
                            ClientPacketListener connection = player.connection;
                            if (connection == null) return;
                            lastSentMessage = finalChatReply;
                            lastSentMessageTime = System.currentTimeMillis();
                            connection.sendChat(finalChatReply);
                        });
                    }
                });
    }

    /** Convertit les accents et caracteres speciaux en ASCII */
    public static String toAscii(String input) {
        if (input == null) return "";
        StringBuilder sb = new StringBuilder();
        for (char c : input.toCharArray()) {
            sb.append(toAsciiChar(c));
        }
        return sb.toString();
    }

    private static char toAsciiChar(char c) {
        switch (c) {
            case 'à': case 'á': case 'â': case 'ã': case 'ä': case 'å': return 'a';
            case 'À': case 'Á': case 'Â': case 'Ã': case 'Ä': case 'Å': return 'A';
            case 'è': case 'é': case 'ê': case 'ë': return 'e';
            case 'È': case 'É': case 'Ê': case 'Ë': return 'E';
            case 'ì': case 'í': case 'î': case 'ï': return 'i';
            case 'Ì': case 'Í': case 'Î': case 'Ï': return 'I';
            case 'ò': case 'ó': case 'ô': case 'õ': case 'ö': case 'ø': return 'o';
            case 'Ò': case 'Ó': case 'Ô': case 'Õ': case 'Ö': case 'Ø': return 'O';
            case 'ù': case 'ú': case 'û': case 'ü': return 'u';
            case 'Ù': case 'Ú': case 'Û': case 'Ü': return 'U';
            case 'ç': return 'c';
            case 'Ç': return 'C';
            case 'ñ': return 'n';
            case 'Ñ': return 'N';
            case 'ý': case 'ÿ': return 'y';
            case 'Ý': return 'Y';
            case 'ß': return 's';
            case 'æ': return 'a';
            case 'Æ': return 'A';
            case 'œ': return 'o';
            case 'Œ': return 'O';
            default:
                // Supprime emojis et caracteres non-ASCII (hors ponctuation basique)
                if (c < 128 || c == '€' || c == '£' || c == '¥') {
                    return c;
                }
                // Si c'est un emoji ou un caractere special, on le saute
                if (c >= 0x1F600 && c <= 0x1F64F) return ' '; // emojis
                if (c >= 0x2600 && c <= 0x26FF) return ' ';   // symboles
                if (c >= 0x2700 && c <= 0x27BF) return ' ';   // dingbats
                return ' ';
        }
    }

    private static String sanitizeChatMessage(String raw) {
        if (raw == null) return "";
        String cleaned = raw.replace("\n", " ").replace("\r", " ").replace("\t", " ");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < cleaned.length(); i++) {
            char c = cleaned.charAt(i);
            if (c >= 32 && c != 127) {
                sb.append(c);
            }
        }
        String result = sb.toString().trim().replaceAll(" +", " ");
        if (result.length() > 256) {
            result = result.substring(0, 256).trim();
        }
        return result;
    }

    private static String buildChatSystemPrompt(String basePrompt, String langCode) {
        StringBuilder sb = new StringBuilder();
        sb.append(basePrompt);
        sb.append(" You are chatting with players in Minecraft. ");
        if ("auto".equalsIgnoreCase(langCode)) {
            sb.append("Always respond in the SAME LANGUAGE as the user's message. ");
        } else {
            sb.append("Always respond in ").append(langCode).append(". ");
        }
        sb.append("Be witty, brief and natural. ");
        sb.append("You may also include a simple action in JSON: {\"response\":\"your chat msg\",\"action\":\"fwd\",\"parameters\":{\"duration\":\"20\"}}");
        return sb.toString();
    }
}
