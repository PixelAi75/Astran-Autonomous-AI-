package com.example.astranautonomousminecraftai;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;

public class AstranWorldContext {

    public static String buildUltraCompactContext() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return "N";

        Player p = mc.player;
        BlockPos pos = p.blockPosition();
        StringBuilder sb = new StringBuilder();

        // Position + vie + faim (format: x,y,z|h/H|f)
        sb.append(pos.getX()).append(",").append(pos.getY()).append(",").append(pos.getZ());
        sb.append("|").append((int)p.getHealth()).append("/").append((int)p.getMaxHealth());
        sb.append("|").append(p.getFoodData().getFoodLevel());

        // Biome abrégé
        String biome = mc.level.getBiome(pos).unwrapKey()
                .map(k -> {
                    String s = k.toString();
                    int i = s.lastIndexOf(" / ");
                    String name = i != -1 ? s.substring(i + 3).replace("]", "").replace("minecraft:", "") : s;
                    return name.length() > 6 ? name.substring(0,6) : name;
                }).orElse("?");
        sb.append("|").append(biome);

        // Jour/Nuit
        sb.append("|").append(mc.level.getDayTime() % 24000L < 13000 ? "D" : "N");

        // Hotbar (max 3 items)
        sb.append("|I:");
        int items = 0;
        for (int i = 0; i < 9 && items < 3; i++) {
            ItemStack s = p.getInventory().getItem(i);
            if (!s.isEmpty()) {
                if (items > 0) sb.append(",");
                String name = s.getItem().getDescriptionId();
                int dot = name.lastIndexOf('.');
                name = dot > 0 ? name.substring(dot+1) : name;
                if (name.length() > 8) name = name.substring(0,8);
                sb.append(i).append(":").append(name).append("x").append(s.getCount());
                items++;
            }
        }

        // Blocs proches (max 4, rayon 2)
        sb.append("|B:");
        java.util.Set<String> blocks = new java.util.LinkedHashSet<>();
        for (int dx = -2; dx <= 2 && blocks.size() < 4; dx++) {
            for (int dy = -1; dy <= 1 && blocks.size() < 4; dy++) {
                for (int dz = -2; dz <= 2 && blocks.size() < 4; dz++) {
                    BlockPos bp = pos.offset(dx, dy, dz);
                    var state = mc.level.getBlockState(bp);
                    if (!state.isAir() && state.getBlock() != Blocks.CAVE_AIR) {
                        String bname = state.getBlock().getDescriptionId();
                        int dot = bname.lastIndexOf('.');
                        bname = dot > 0 ? bname.substring(dot+1) : bname;
                        if (bname.length() > 8) bname = bname.substring(0,8);
                        blocks.add(bname);
                    }
                }
            }
        }
        int bidx = 0;
        for (String b : blocks) {
            if (bidx++ > 0) sb.append(",");
            sb.append(b);
        }

        // Entités proches (max 2 joueurs + 2 mobs)
        sb.append("|E:");
        var nearby = mc.level.getEntities(p, p.getBoundingBox().inflate(12.0));
        int pc = 0, mc2 = 0;
        for (Entity e : nearby) {
            if (e == p) continue;
            if (e instanceof Player pl && pc < 2) {
                if (pc+mc2 > 0) sb.append(",");
                String name = pl.getName().getString();
                if (name.length() > 6) name = name.substring(0,6);
                sb.append(name).append("@").append((int)p.distanceTo(e)).append("m");
                pc++;
            } else if (e instanceof LivingEntity le && !(e instanceof Player) && mc2 < 2) {
                if (pc+mc2 > 0) sb.append(",");
                String type = le.getType().getDescriptionId();
                int dot = type.lastIndexOf('.');
                type = dot > 0 ? type.substring(dot+1) : type;
                if (type.length() > 8) type = type.substring(0,8);
                sb.append(type).append("@").append((int)p.distanceTo(e)).append("m");
                mc2++;
            }
            if (pc >= 2 && mc2 >= 2) break;
        }

        // Block visé
        var hit = mc.hitResult;
        if (hit != null && hit.getType() == net.minecraft.world.phys.HitResult.Type.BLOCK) {
            var bh = (net.minecraft.world.phys.BlockHitResult) hit;
            String block = mc.level.getBlockState(bh.getBlockPos()).getBlock().getDescriptionId();
            int dot = block.lastIndexOf('.');
            block = dot > 0 ? block.substring(dot+1) : block;
            if (block.length() > 8) block = block.substring(0,8);
            sb.append("|L:").append(block);
        }

        return sb.toString();
    }
}
