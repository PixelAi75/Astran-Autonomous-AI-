package com.example.astranautonomousminecraftai;

import java.util.List;

public class AstranLanguage {
    public static final List<Lang> LANGUAGES = List.of(
            new Lang("auto", "Auto (detect chat language)"),
            new Lang("en", "English"),
            new Lang("fr", "French"),
            new Lang("es", "Spanish"),
            new Lang("de", "German"),
            new Lang("it", "Italian"),
            new Lang("pt", "Portuguese"),
            new Lang("ja", "Japanese"),
            new Lang("ko", "Korean"),
            new Lang("zh", "Chinese"),
            new Lang("ru", "Russian"),
            new Lang("ar", "Arabic"),
            new Lang("nl", "Dutch"),
            new Lang("pl", "Polish"),
            new Lang("tr", "Turkish"),
            new Lang("sv", "Swedish"),
            new Lang("hi", "Hindi"),
            new Lang("th", "Thai"),
            new Lang("vi", "Vietnamese"),
            new Lang("id", "Indonesian")
    );

    public static Lang getByCode(String code) {
        for (Lang lang : LANGUAGES) {
            if (lang.code.equalsIgnoreCase(code)) return lang;
        }
        return LANGUAGES.get(0); // auto
    }

    public static Lang getNext(String currentCode) {
        for (int i = 0; i < LANGUAGES.size(); i++) {
            if (LANGUAGES.get(i).code.equalsIgnoreCase(currentCode)) {
                return LANGUAGES.get((i + 1) % LANGUAGES.size());
            }
        }
        return LANGUAGES.get(0);
    }

    public static class Lang {
        public final String code;
        public final String displayName;

        public Lang(String code, String displayName) {
            this.code = code;
            this.displayName = displayName;
        }
    }
}
