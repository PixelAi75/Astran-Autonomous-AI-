package com.example.astranautonomousminecraftai;

import org.slf4j.Logger;
import com.mojang.logging.LogUtils;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.server.ServerStartingEvent;

@Mod(AstranAutonomousMinecraftAi.MODID)
public class AstranAutonomousMinecraftAi {
    public static final String MODID = "astranautonomousminecraftai";
    public static final Logger LOGGER = LogUtils.getLogger();

    public AstranAutonomousMinecraftAi(IEventBus modEventBus) {
        modEventBus.addListener(this::commonSetup);
        NeoForge.EVENT_BUS.register(this);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        LOGGER.info("[Astran Autonomous Minecraft AI] Common setup complete.");
    }

    @SubscribeEvent
    public void onServerStarting(ServerStartingEvent event) {
        LOGGER.info("[Astran Autonomous Minecraft AI] Server starting.");
    }
}
