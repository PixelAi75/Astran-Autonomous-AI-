package com.example.astranautonomousminecraftai;

import java.util.HashMap;
import java.util.Map;

public class AstranAiResponse {
    public String thought = "";
    public String response = "";
    public String action = "none";
    public Map<String, String> parameters = new HashMap<>();
    public boolean hasTask = false;
    public String taskType = "";
    public String taskBlock = "";
    public String taskPos = "";
    public int taskQty = 1;
    public String taskDesc = "";

    public static AstranAiResponse parse(String raw) {
        AstranAiResponse r = new AstranAiResponse();
        if (raw == null || raw.isBlank()) return r;

        String json = extractJsonBlock(raw);
        if (json == null) {
            r.response = raw.trim();
            return r;
        }

        r.thought = extractField(json, "thought");
        r.response = extractField(json, "response");
        r.action = extractField(json, "action");
        if (r.action.isEmpty()) r.action = "none";

        // Parse task
        String task = extractField(json, "task");
        if (!task.isEmpty()) {
            r.hasTask = true;
            r.taskType = task;
            r.taskBlock = extractField(json, "block");
            r.taskPos = extractField(json, "pos");
            String qtyStr = extractField(json, "qty");
            if (!qtyStr.isEmpty()) {
                try { r.taskQty = Integer.parseInt(qtyStr); } catch (NumberFormatException ignored) {}
            }
            r.taskDesc = extractField(json, "desc");
            if (r.taskDesc.isEmpty()) r.taskDesc = task + " " + r.taskBlock;
        }

        String params = extractObject(json, "parameters");
        if (!params.isEmpty()) {
            r.parameters = parseSimpleObject(params);
        }

        return r;
    }

    private static String extractJsonBlock(String raw) {
        int start = raw.indexOf('{');
        int end = raw.lastIndexOf('}');
        if (start == -1 || end == -1 || end <= start) return null;
        return raw.substring(start, end + 1);
    }

    private static String extractField(String json, String fieldName) {
        String search = "\"" + fieldName + "\"";
        int idx = json.indexOf(search);
        if (idx == -1) return "";
        int colon = json.indexOf(':', idx + search.length());
        if (colon == -1) return "";
        int i = colon + 1;
        while (i < json.length() && Character.isWhitespace(json.charAt(i))) i++;
        if (i >= json.length()) return "";
        char c = json.charAt(i);
        if (c == '"') {
            return extractQuotedString(json, i + 1);
        } else {
            int end = i;
            while (end < json.length() && json.charAt(end) != ',' && json.charAt(end) != '}') {
                end++;
            }
            return json.substring(i, end).trim();
        }
    }

    private static String extractQuotedString(String json, int start) {
        StringBuilder sb = new StringBuilder();
        boolean escaped = false;
        for (int i = start; i < json.length(); i++) {
            char c = json.charAt(i);
            if (escaped) {
                switch (c) {
                    case 'n' -> sb.append('\n');
                    case 't' -> sb.append('\t');
                    case 'r' -> sb.append('\r');
                    case 'u' -> {
                        if (i + 4 < json.length()) {
                            try {
                                String hex = json.substring(i + 1, i + 5);
                                sb.append((char) Integer.parseInt(hex, 16));
                                i += 4;
                            } catch (NumberFormatException e) { sb.append('u'); }
                        }
                    }
                    default -> sb.append(c);
                }
                escaped = false;
            } else if (c == '\\') {
                escaped = true;
            } else if (c == '"') {
                break;
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    private static String extractObject(String json, String fieldName) {
        String search = "\"" + fieldName + "\"";
        int idx = json.indexOf(search);
        if (idx == -1) return "";
        int colon = json.indexOf(':', idx + search.length());
        if (colon == -1) return "";
        int brace = json.indexOf('{', colon);
        if (brace == -1) return "";
        int depth = 1;
        int i = brace + 1;
        while (i < json.length() && depth > 0) {
            char c = json.charAt(i);
            if (c == '{') depth++;
            else if (c == '}') depth--;
            else if (c == '"') {
                i++;
                while (i < json.length() && json.charAt(i) != '"') {
                    if (json.charAt(i) == '\\') i++;
                    i++;
                }
            }
            i++;
        }
        return json.substring(brace + 1, i - 1);
    }

    private static Map<String, String> parseSimpleObject(String inner) {
        Map<String, String> map = new HashMap<>();
        if (inner == null || inner.isBlank()) return map;
        int i = 0;
        while (i < inner.length()) {
            while (i < inner.length() && Character.isWhitespace(inner.charAt(i))) i++;
            if (i >= inner.length() || inner.charAt(i) == '}') break;
            if (inner.charAt(i) == '"') {
                String key = extractQuotedString(inner, i + 1);
                i = inner.indexOf('"', i + 1) + 1;
                while (i < inner.length() && (inner.charAt(i) == ':' || Character.isWhitespace(inner.charAt(i)))) i++;
                if (i >= inner.length()) break;
                String value;
                if (inner.charAt(i) == '"') {
                    value = extractQuotedString(inner, i + 1);
                    i = inner.indexOf('"', i + 1) + 1;
                } else {
                    int end = i;
                    while (end < inner.length() && inner.charAt(end) != ',' && inner.charAt(end) != '}') {
                        end++;
                    }
                    value = inner.substring(i, end).trim();
                    i = end;
                }
                map.put(key, value);
                while (i < inner.length() && (inner.charAt(i) == ',' || Character.isWhitespace(inner.charAt(i)))) i++;
            } else {
                i++;
            }
        }
        return map;
    }
}
