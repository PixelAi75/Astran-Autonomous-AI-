package com.example.astranautonomousminecraftai;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.concurrent.CompletableFuture;

public class AstranApiClient {
    private static final HttpClient HTTP_CLIENT = HttpClient.newHttpClient();
    private static final String MISTRAL_API_URL = "https://api.mistral.ai/v1/chat/completions";
    private static final String MISTRAL_MODELS_URL = "https://api.mistral.ai/v1/models";

    public static CompletableFuture<Boolean> testConnectionAsync(String apiKey) {
        if (apiKey == null || apiKey.isBlank()) {
            return CompletableFuture.completedFuture(false);
        }

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(MISTRAL_MODELS_URL))
                .header("Authorization", "Bearer " + apiKey)
                .header("Accept", "application/json")
                .GET()
                .timeout(java.time.Duration.ofSeconds(10))
                .build();

        return HTTP_CLIENT.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(response -> response.statusCode() == 200)
                .exceptionally(ex -> {
                    AstranAutonomousMinecraftAi.LOGGER.warn("Astran API test failed: {}", ex.getMessage());
                    return false;
                });
    }

    public static CompletableFuture<String> sendChatToAiAsync(String apiKey, String model, String systemPrompt, String userMessage) {
        if (apiKey == null || apiKey.isBlank()) {
            return CompletableFuture.completedFuture(null);
        }

        // Chat utilise son propre modele (pas ecrase par le router d'actions)
        // Pas de rate limit strict pour le chat - on laisse passer
        if (!AstranModelRouter.canSendRequest(model)) {
            long wait = AstranModelRouter.getWaitTimeMs(model);
            AstranAutonomousMinecraftAi.LOGGER.debug("[AstranApi] Chat rate limit for {}, wait {}ms", model, wait);
        }

        String jsonBody = buildChatPayload(model, systemPrompt, userMessage);
        int estTokens = AstranModelRouter.estimateTokens(systemPrompt + userMessage);
        AstranModelRouter.recordRequest(model, estTokens);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(MISTRAL_API_URL))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                .timeout(java.time.Duration.ofSeconds(30))
                .build();

        final String finalModel = model;
        return HTTP_CLIENT.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(response -> {
                    int status = response.statusCode();
                    if (status == 429) {
                        AstranAutonomousMinecraftAi.LOGGER.warn("[AstranApi] 429 Rate limit on {}", finalModel);
                        AstranModelRouter.recordFailure(finalModel, 429);
                        return null;
                    }
                    if (status != 200) {
                        AstranAutonomousMinecraftAi.LOGGER.warn("[AstranApi] Status {} on {}", status, finalModel);
                        AstranModelRouter.recordFailure(finalModel, status);
                        return null;
                    }
                    AstranModelRouter.recordSuccess(finalModel);
                    return extractContent(response.body());
                })
                .exceptionally(ex -> {
                    AstranAutonomousMinecraftAi.LOGGER.warn("[AstranApi] Exception on {}: {}", finalModel, ex.getMessage());
                    AstranModelRouter.recordFailure(finalModel, -1);
                    return null;
                });
    }

    public static CompletableFuture<String> sendAutonomousAiAsync(String apiKey, String model, String systemPrompt, String worldContext, String goal, String userMessage) {
        if (apiKey == null || apiKey.isBlank()) {
            return CompletableFuture.completedFuture(null);
        }

        // Actions utilisent le modele passe (deja verifie par ensureCanSend)
        // Build ultra-compact user message
        StringBuilder userBuilder = new StringBuilder();
        userBuilder.append("W:").append(worldContext).append("|");
        userBuilder.append("G:").append(goal).append("|");
        userBuilder.append("C:").append(userMessage).append("|");
        userBuilder.append("R:JSON{t:thought,r:response,a:action,p:params}OR{t:thought,r:response,task:type,block:name,pos:x,y,z,qty:n,desc:text}");

        String jsonBody = buildChatPayload(model, systemPrompt, userBuilder.toString());
        int estTokens = AstranModelRouter.estimateTokens(systemPrompt + userBuilder.toString());

        // Vérifier rate limit - si bloqué, fallback immédiat
        if (!AstranModelRouter.canSendRequest(model)) {
            long wait = AstranModelRouter.getWaitTimeMs(model);
            AstranAutonomousMinecraftAi.LOGGER.debug("[AstranApi] Rate limit for {}, wait {}ms", model, wait);
            if (wait > 3000) {
                AstranModelRouter.fallbackToNext(model);
                model = AstranModelRouter.getCurrentModel();
                jsonBody = buildChatPayload(model, systemPrompt, userBuilder.toString());
            }
            // Si wait < 3s, on envoie quand même et on laisse le routeur gérer
        }

        AstranModelRouter.recordRequest(model, estTokens);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(MISTRAL_API_URL))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                .timeout(java.time.Duration.ofSeconds(30))
                .build();

        final String finalModel = model;
        return HTTP_CLIENT.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(response -> {
                    int status = response.statusCode();
                    if (status == 429) {
                        AstranAutonomousMinecraftAi.LOGGER.warn("[AstranApi] 429 Rate limit on {}", finalModel);
                        AstranModelRouter.recordFailure(finalModel, 429);
                        return null;
                    }
                    if (status != 200) {
                        AstranAutonomousMinecraftAi.LOGGER.warn("[AstranApi] Status {} on {}", status, finalModel);
                        String respBody = response.body();
                        if (respBody != null && !respBody.isBlank()) {
                            AstranAutonomousMinecraftAi.LOGGER.warn("Response: {}", respBody.substring(0, Math.min(respBody.length(), 200)));
                        }
                        AstranModelRouter.recordFailure(finalModel, status);
                        return null;
                    }
                    AstranModelRouter.recordSuccess(finalModel);
                    return extractContent(response.body());
                })
                .exceptionally(ex -> {
                    AstranAutonomousMinecraftAi.LOGGER.warn("[AstranApi] Exception on {}: {}", finalModel, ex.getMessage());
                    AstranModelRouter.recordFailure(finalModel, -1);
                    return null;
                });
    }

    private static String buildChatPayload(String model, String systemPrompt, String userMessage) {
        StringBuilder sb = new StringBuilder();
        sb.append('{');
        sb.append('"').append("model").append('"').append(':').append('"').append(escapeJson(model)).append('"').append(',');
        sb.append('"').append("messages").append('"').append(':').append('[');
        sb.append('{').append('"').append("role").append('"').append(':').append('"').append("system").append('"').append(',');
        sb.append('"').append("content").append('"').append(':').append('"').append(escapeJson(systemPrompt)).append('"').append('}').append(',');
        sb.append('{').append('"').append("role").append('"').append(':').append('"').append("user").append('"').append(',');
        sb.append('"').append("content").append('"').append(':').append('"').append(escapeJson(userMessage)).append('"').append('}');
        sb.append(']').append('}');
        return sb.toString();
    }

    private static String extractContent(String json) {
        String assistantMarker = "\"role\":\"assistant\"";
        int assistantIdx = json.indexOf(assistantMarker);
        if (assistantIdx == -1) {
            assistantMarker = "\"role\": \"assistant\"";
            assistantIdx = json.indexOf(assistantMarker);
            if (assistantIdx == -1) return null;
        }

        String search = "\"content\":\"";
        int idx = json.indexOf(search, assistantIdx);
        if (idx == -1) {
            search = "\"content\": \"";
            idx = json.indexOf(search, assistantIdx);
            if (idx == -1) return null;
        }

        int start = idx + search.length();
        StringBuilder sb = new StringBuilder();
        boolean escaped = false;
        for (int i = start; i < json.length(); i++) {
            char c = json.charAt(i);
            if (escaped) {
                switch (c) {
                    case 'n' -> sb.append('\n');
                    case 't' -> sb.append('\t');
                    case 'r' -> sb.append('\r');
                    case 'u' -> {
                        if (i + 4 < json.length()) {
                            try {
                                String hex = json.substring(i + 1, i + 5);
                                sb.append((char) Integer.parseInt(hex, 16));
                                i += 4;
                            } catch (NumberFormatException e) {
                                sb.append('u');
                            }
                        }
                    }
                    default -> sb.append(c);
                }
                escaped = false;
            } else if (c == '\\') {
                escaped = true;
            } else if (c == '"') {
                break;
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    private static String escapeJson(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c < 0x20) {
                switch (c) {
                    case '\n' -> sb.append("\\n");
                    case '\r' -> sb.append("\\r");
                    case '\t' -> sb.append("\\t");
                    case '\b' -> sb.append("\\b");
                    case '\f' -> sb.append("\\f");
                    default -> sb.append(String.format("\\u%04x", (int) c));
                }
            } else {
                switch (c) {
                    case '"' -> sb.append("\\\"");
                    case '\\' -> sb.append("\\\\");
                    default -> sb.append(c);
                }
            }
        }
        return sb.toString();
    }
}
