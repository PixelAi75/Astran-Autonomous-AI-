package com.example.astranautonomousminecraftai;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class AstranTips {
    private static final long TIP_COOLDOWN_MS = 10 * 60 * 1000L; // 10 minutes
    private static final Random RANDOM = new Random();
    private static long lastTipTime = 0L;

    private static final List<String> GENERAL_TIPS = List.of(
            "astran.tip.settings",
            "astran.tip.disable",
            "astran.tip.test",
            "astran.tip.clear",
            "astran.tip.personality",
            "astran.tip.mentions"
    );

    public static void tryShowTip() {
        if (!AstranConfig.TIPS_ENABLED.get()) return;
        if (Minecraft.getInstance().player == null) return;

        long now = System.currentTimeMillis();
        long savedLastTip = AstranConfig.LAST_TIP_TIME.get();
        long effectiveLastTip = Math.max(lastTipTime, savedLastTip);

        if (now - effectiveLastTip < TIP_COOLDOWN_MS) return;

        String tipKey = selectContextualTip();
        if (tipKey == null) return;

        lastTipTime = now;
        AstranConfig.LAST_TIP_TIME.set(now);

        Component tip = Component.translatable("astran.prefix.tip")
                .append(" ")
                .append(Component.translatable(tipKey))
                .setStyle(Style.EMPTY.withColor(ChatFormatting.GRAY));

        Minecraft.getInstance().player.displayClientMessage(tip, false);
    }

    private static String selectContextualTip() {
        List<String> candidates = new ArrayList<>();

        boolean hasKey = AstranConfig.API_KEY.get() != null && !AstranConfig.API_KEY.get().isBlank();
        boolean hasTested = AstranConfig.HAS_TESTED_API.get();
        boolean aiEnabled = AstranConfig.AI_ENABLED.get();

        if (!hasKey) {
            candidates.add("astran.tip.configure_key");
        }
        if (!hasTested && hasKey) {
            candidates.add("astran.tip.test_connection");
        }
        if (!aiEnabled) {
            candidates.add("astran.tip.ai_disabled");
        }

        if (candidates.isEmpty() || RANDOM.nextBoolean()) {
            candidates.addAll(GENERAL_TIPS);
        }

        if (candidates.isEmpty()) return null;
        return candidates.get(RANDOM.nextInt(candidates.size()));
    }

    public static void resetCooldown() {
        lastTipTime = 0L;
    }
}
