package com.example.astranautonomousminecraftai;

import net.minecraft.core.BlockPos;

public class AstranTask {
    public String type = "none";
    public String targetBlock = "";
    public BlockPos targetPos = null;
    public int quantity = 1;
    public String description = "";

    public Step currentStep = Step.IDLE;
    public int stepTicks = 0;
    public int itemsCollected = 0;
    public boolean completed = false;
    public boolean failed = false;
    public String failReason = "";

    public enum Step {
        IDLE, FIND, PATHFIND, APPROACH, LOOK, BREAK, WAIT_DROP, COLLECT, DONE
    }

    public static AstranTask parse(java.util.Map<String, String> params) {
        AstranTask t = new AstranTask();
        t.type = params.getOrDefault("task", "none");
        t.targetBlock = params.getOrDefault("block", "");
        String posStr = params.getOrDefault("pos", "");
        if (!posStr.isBlank()) {
            t.targetPos = parsePos(posStr);
        }
        try {
            t.quantity = Integer.parseInt(params.getOrDefault("qty", "1"));
        } catch (NumberFormatException ignored) {}
        t.description = params.getOrDefault("desc", t.type + " " + t.targetBlock);
        return t;
    }

    public static BlockPos parsePos(String s) {
        if (s == null || s.isBlank()) return null;
        String[] parts = s.split(",");
        if (parts.length >= 3) {
            try {
                int x = Integer.parseInt(parts[0].trim());
                int y = Integer.parseInt(parts[1].trim());
                int z = Integer.parseInt(parts[2].trim());
                return new BlockPos(x, y, z);
            } catch (NumberFormatException ignored) {}
        }
        return null;
    }

    public boolean hasTargetPos() {
        return targetPos != null;
    }
}
