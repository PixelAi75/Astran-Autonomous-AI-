package com.example.astranautonomousminecraftai;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;

public class AstranGoalManager {

    public static void setGoal(String goal) {
        AstranConfig.GOAL.set(goal);
        if (Minecraft.getInstance().player != null) {
            Minecraft.getInstance().player.displayClientMessage(
                    Component.literal("[Astran] Goal set: ").setStyle(Style.EMPTY.withColor(ChatFormatting.AQUA))
                            .append(Component.literal(goal).setStyle(Style.EMPTY.withColor(ChatFormatting.WHITE))),
                    false);
        }
    }

    public static String getGoal() {
        String goal = AstranConfig.GOAL.get();
        return goal == null || goal.isBlank() ? "No active goal." : goal;
    }

    public static void clearGoal() {
        AstranConfig.GOAL.set("");
    }
}
