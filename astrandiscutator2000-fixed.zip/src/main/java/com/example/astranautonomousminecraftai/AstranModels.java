package com.example.astranautonomousminecraftai;

import java.util.List;

public class AstranModels {
    public static final List<Model> MODELS = List.of(
            new Model("ministral-3b-2512", "Ministral 3B (Ultra Fast)", 1300000, 12.50),
            new Model("ministral-8b-2512", "Ministral 8B (Fast, Recommended)", 625000, 3.13),
            new Model("codestral-2508", "Codestral (Code)", 625000, 2.08),
            new Model("ministral-14b-2512", "Ministral 14B (Balanced)", 937500, 0.50),
            new Model("devstral-2512", "Devstral (Smart)", 1000000, 0.83),
            new Model("mistral-medium-2508", "Mistral Medium", 356250, 0.38),
            new Model("mistral-large-2512", "Mistral Large (Best)", 250000, 0.07)
    );

    public static Model getById(String id) {
        for (Model m : MODELS) {
            if (m.id.equals(id)) return m;
        }
        return MODELS.get(0);
    }

    public static Model getNext(String currentId) {
        for (int i = 0; i < MODELS.size(); i++) {
            if (MODELS.get(i).id.equals(currentId)) {
                return MODELS.get((i + 1) % MODELS.size());
            }
        }
        return MODELS.get(0);
    }

    public static class Model {
        public final String id;
        public final String displayName;
        public final int tokensPerMinute;
        public final double requestsPerSecond;

        public Model(String id, String displayName, int tokensPerMinute, double requestsPerSecond) {
            this.id = id;
            this.displayName = displayName;
            this.tokensPerMinute = tokensPerMinute;
            this.requestsPerSecond = requestsPerSecond;
        }

        public long getMinIntervalMs() {
            return (long) Math.ceil(1000.0 / requestsPerSecond);
        }
    }
}
