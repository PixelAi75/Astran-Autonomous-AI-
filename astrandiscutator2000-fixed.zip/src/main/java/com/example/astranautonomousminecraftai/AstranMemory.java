package com.example.astranautonomousminecraftai;

import java.util.ArrayList;
import java.util.List;

public class AstranMemory {
    private static final List<String> messages = new ArrayList<>();
    private static final int MAX_MEMORY = 50;

    public static void addMessage(String role, String content) {
        messages.add(role + ": " + content);
        if (messages.size() > MAX_MEMORY) {
            messages.remove(0);
        }
    }

    public static List<String> getMessages() {
        return new ArrayList<>(messages);
    }

    public static int getMessageCount() {
        return messages.size();
    }

    public static void clear() {
        messages.clear();
    }
}
