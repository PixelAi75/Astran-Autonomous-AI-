package com.example.astranautonomousminecraftai;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class AstranWelcome {
    private static final ScheduledExecutorService SCHEDULER = Executors.newSingleThreadScheduledExecutor(
            r -> new Thread(r, "Astran-Welcome")
    );

    private static final String[] WELCOME_KEYS = {
            "astran.welcome.line1",
            "astran.welcome.line2",
            "astran.welcome.line3",
            "astran.welcome.line4",
            "astran.welcome.line5",
            "astran.welcome.line6"
    };

    public static void onClientReady() {
        if (AstranConfig.HAS_SEEN_WELCOME.get()) return;

        // Mark as seen immediately to prevent duplicates on rapid rejoins
        AstranConfig.HAS_SEEN_WELCOME.set(true);

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        Style prefixStyle = Style.EMPTY.withColor(ChatFormatting.GRAY);

        for (int i = 0; i < WELCOME_KEYS.length; i++) {
            final int idx = i;
            SCHEDULER.schedule(() -> {
                mc.execute(() -> {
                    if (mc.player != null) {
                        MutableComponent msg = Component.translatable("astran.prefix.mod").copy();
                        msg.append(" ");
                        msg.append(Component.translatable(WELCOME_KEYS[idx]));
                        msg.setStyle(prefixStyle);
                        mc.player.displayClientMessage(msg, false);
                    }
                });
            }, i * 800L, TimeUnit.MILLISECONDS);
        }
    }

    public static void resetWelcome() {
        AstranConfig.HAS_SEEN_WELCOME.set(false);
    }

    public static void shutdown() {
        SCHEDULER.shutdown();
    }
}
