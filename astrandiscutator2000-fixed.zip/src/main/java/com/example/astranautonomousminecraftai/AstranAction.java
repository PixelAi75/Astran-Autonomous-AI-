package com.example.astranautonomousminecraftai;

public enum AstranAction {
    NONE("none", "Do nothing"),
    MOVE_FORWARD("move_forward", "Walk forward"),
    MOVE_BACKWARD("move_backward", "Walk backward"),
    MOVE_LEFT("move_left", "Strafe left"),
    MOVE_RIGHT("move_right", "Strafe right"),
    JUMP("jump", "Jump"),
    SNEAK("sneak", "Sneak/crouch"),
    SPRINT("sprint", "Sprint"),
    STOP("stop", "Stop all movement"),
    PLACE_BLOCK("place_block", "Place block at looking position"),
    BREAK_BLOCK("break_block", "Break block being looked at"),
    USE_ITEM("use_item", "Use held item (right click)"),
    ATTACK("attack", "Attack entity being looked at"),
    DROP_ITEM("drop_item", "Drop held item"),
    SWAP_SLOT("swap_slot", "Change hotbar slot"),
    LOOK_AT("look_at", "Look at coordinates"),
    SAY("say", "Send a chat message"),
    SET_GOAL("set_goal", "Set a new goal");

    public final String id;
    public final String description;

    AstranAction(String id, String description) {
        this.id = id;
        this.description = description;
    }

    public static AstranAction fromId(String id) {
        for (AstranAction a : values()) {
            if (a.id.equalsIgnoreCase(id)) return a;
        }
        return NONE;
    }
}
