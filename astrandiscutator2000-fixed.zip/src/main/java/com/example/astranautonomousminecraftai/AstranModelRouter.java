package com.example.astranautonomousminecraftai;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public class AstranModelRouter {
    private static final Map<String, ModelState> STATES = new ConcurrentHashMap<>();
    private static final AtomicReference<String> CURRENT_MODEL = new AtomicReference<>();
    private static final long FALLBACK_RESET_MS = 30000; // 30 sec seulement

    private static long lastFallbackTime = 0;
    private static String preferredModel = null;

    static {
        for (AstranModels.Model m : AstranModels.MODELS) {
            STATES.put(m.id, new ModelState(m));
        }
    }

    public static void init(String preferred) {
        preferredModel = preferred;
        CURRENT_MODEL.set(preferred);
        lastFallbackTime = 0;
        AstranAutonomousMinecraftAi.LOGGER.info("[AstranRouter] Preferred model: {}", preferred);
    }

    public static String getCurrentModel() {
        String current = CURRENT_MODEL.get();
        if (current == null) current = AstranConfig.MODEL.get();
        return current;
    }

    /** Si le modele actuel est bloque, fallback immediatement vers le prochain disponible */
    public static String ensureCanSend() {
        String current = getCurrentModel();
        if (canSendRequest(current)) {
            return current;
        }
        // Fallback immediat
        fallbackToNext(current);
        return getCurrentModel();
    }

    public static boolean canSendRequest() {
        return canSendRequest(getCurrentModel());
    }

    public static boolean canSendRequest(String modelId) {
        ModelState state = STATES.get(modelId);
        if (state == null) return false;
        return state.canSend();
    }

    public static long getWaitTimeMs() {
        return getWaitTimeMs(getCurrentModel());
    }

    public static long getWaitTimeMs(String modelId) {
        ModelState state = STATES.get(modelId);
        if (state == null) return Long.MAX_VALUE;
        return state.getWaitTimeMs();
    }

    public static void recordRequest(String modelId, int estimatedTokens) {
        ModelState state = STATES.get(modelId);
        if (state != null) {
            state.recordRequest(estimatedTokens);
        }
    }

    public static void recordSuccess(String modelId) {
        ModelState state = STATES.get(modelId);
        if (state != null) {
            state.recordSuccess();
        }
        if (preferredModel != null && !preferredModel.equals(modelId)) {
            if (System.currentTimeMillis() - lastFallbackTime > FALLBACK_RESET_MS) {
                ModelState pref = STATES.get(preferredModel);
                if (pref != null && pref.canSend()) {
                    AstranAutonomousMinecraftAi.LOGGER.info("[AstranRouter] Resetting to preferred model: {}", preferredModel);
                    CURRENT_MODEL.set(preferredModel);
                }
            }
        }
    }

    public static void recordFailure(String modelId, int statusCode) {
        ModelState state = STATES.get(modelId);
        if (state != null) {
            state.recordFailure();
        }
        if (statusCode == 429) {
            fallbackToNext(modelId);
        }
    }

    public static void fallbackToNext(String failedModelId) {
        AstranModels.Model next = AstranModels.getNext(failedModelId);
        if (next == null || next.id.equals(failedModelId)) {
            AstranAutonomousMinecraftAi.LOGGER.warn("[AstranRouter] No fallback available for {}", failedModelId);
            return;
        }
        ModelState nextState = STATES.get(next.id);
        if (nextState != null && nextState.canSend()) {
            AstranAutonomousMinecraftAi.LOGGER.warn("[AstranRouter] Fallback: {} -> {} (rate limit)", failedModelId, next.id);
            CURRENT_MODEL.set(next.id);
            lastFallbackTime = System.currentTimeMillis();
        } else {
            for (AstranModels.Model m : AstranModels.MODELS) {
                if (m.id.equals(failedModelId)) continue;
                ModelState ms = STATES.get(m.id);
                if (ms != null && ms.canSend()) {
                    AstranAutonomousMinecraftAi.LOGGER.warn("[AstranRouter] Fallback: {} -> {} (next unavailable)", failedModelId, m.id);
                    CURRENT_MODEL.set(m.id);
                    lastFallbackTime = System.currentTimeMillis();
                    return;
                }
            }
            AstranAutonomousMinecraftAi.LOGGER.error("[AstranRouter] ALL MODELS RATE LIMITED!");
        }
    }

    public static int estimateTokens(String prompt) {
        return Math.max(1, prompt.length() / 4);
    }

    public static String getStatusDebug() {
        StringBuilder sb = new StringBuilder();
        sb.append("Current: ").append(getCurrentModel()).append("\n");
        for (ModelState state : STATES.values()) {
            sb.append(state.model.id)
              .append(" | RPS: ").append(state.recentRequests.size())
              .append("/").append(String.format("%.2f", state.model.requestsPerSecond))
              .append(" | TPM: ").append(state.recentTokens.stream().mapToInt(e -> e.tokens).sum())
              .append("/").append(state.model.tokensPerMinute)
              .append(" | OK: ").append(state.consecutiveSuccesses)
              .append(" | Fail: ").append(state.consecutiveFailures)
              .append("\n");
        }
        return sb.toString();
    }

    private static class TokenEntry {
        final long time;
        final int tokens;
        TokenEntry(long time, int tokens) {
            this.time = time;
            this.tokens = tokens;
        }
    }

    private static class ModelState {
        final AstranModels.Model model;
        final ConcurrentLinkedQueue<Long> recentRequests = new ConcurrentLinkedQueue<>();
        final ConcurrentLinkedQueue<TokenEntry> recentTokens = new ConcurrentLinkedQueue<>();
        final AtomicInteger consecutiveFailures = new AtomicInteger(0);
        final AtomicInteger consecutiveSuccesses = new AtomicInteger(0);
        volatile long lastRequestTime = 0;

        ModelState(AstranModels.Model model) {
            this.model = model;
        }

        void cleanupOld() {
            long now = System.currentTimeMillis();
            while (!recentRequests.isEmpty() && now - recentRequests.peek() > 60000) {
                recentRequests.poll();
            }
            while (!recentTokens.isEmpty() && now - recentTokens.peek().time > 60000) {
                recentTokens.poll();
            }
        }

        boolean canSend() {
            cleanupOld();
            long now = System.currentTimeMillis();
            long minInterval = model.getMinIntervalMs();
            if (now - lastRequestTime < minInterval) {
                return false;
            }
            if (recentRequests.size() >= (int)(model.requestsPerSecond * 60)) {
                return false;
            }
            int totalTokens = recentTokens.stream().mapToInt(e -> e.tokens).sum();
            if (totalTokens >= model.tokensPerMinute * 0.95) {
                return false;
            }
            return true;
        }

        long getWaitTimeMs() {
            cleanupOld();
            long now = System.currentTimeMillis();
            long minInterval = model.getMinIntervalMs();
            long wait = minInterval - (now - lastRequestTime);
            if (wait > 0) return wait;
            if (recentRequests.size() >= (int)(model.requestsPerSecond * 60)) {
                Long oldest = recentRequests.peek();
                if (oldest != null) {
                    return 60000 - (now - oldest) + 100;
                }
            }
            return 0;
        }

        void recordRequest(int tokens) {
            long now = System.currentTimeMillis();
            recentRequests.add(now);
            recentTokens.add(new TokenEntry(now, tokens));
            lastRequestTime = now;
        }

        void recordSuccess() {
            consecutiveSuccesses.incrementAndGet();
            consecutiveFailures.set(0);
        }

        void recordFailure() {
            consecutiveFailures.incrementAndGet();
            consecutiveSuccesses.set(0);
        }
    }
}
